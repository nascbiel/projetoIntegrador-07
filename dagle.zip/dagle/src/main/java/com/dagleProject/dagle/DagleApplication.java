package com.dagleProject.dagle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DagleApplication {

	public static void main(String[] args) {
		SpringApplication.run(DagleApplication.class, args);
	}

}
