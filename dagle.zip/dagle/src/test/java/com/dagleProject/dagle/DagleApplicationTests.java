package com.dagleProject.dagle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DagleApplicationTests {

	@Test
	void contextLoads() {
	}

}
